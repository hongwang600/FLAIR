import os

# 获取当前工作目录
current_dir = os.getcwd()

# 遍历当前目录下的所有目录
for dir_name in os.listdir(current_dir):
    dir_path = os.path.join(current_dir, dir_name)
    # 检查是否为目录
    if os.path.isdir(dir_path):
        # 获取目录下的文件列表
        files = os.listdir(dir_path)
        # 检查文件数量是否为5
        if len(files) != 5:
            print(f"{dir_name} 目录下有 {len(files)} 个文件, 不是5个文件")